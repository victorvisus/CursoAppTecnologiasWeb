/*
let animales = ["gato","perro","serpiente","tortuga","sardina"]
console.log(animales[animales.length-1])
console.log("la cantidad de animales es: " + animales.length)

//array vacío
let arrayVacio = []
let otroArrayVacio = new Array()
console.log(arrayVacio.length)
console.log(otroArrayVacio.length)

//acceso y modificación:
console.log(animales)
animales[1] = "caballo"
console.log(animales)
//para añadir al final de modo "irresponsable", dejando vacíos
// previos:
animales[animales.length+1]="jabalí"
console.log(animales)
console.log(animales[5])
// corregirlo poniendo algo en la posición vacía
animales[5]="gato"

//para añadir al final de modo ordenado:
animales[animales.length]="jabalí"
console.log(animales)
console.log(animales[5])

animales.push("cabra")
animales.unshift("águila")
console.log(animales)

// recorrido secuencial
for (let i=0; i<animales.length; i++){
    console.log(`El animal en la posición ${i+1} es ${animales[i]}`)
}
let rentas = [787, 763, 876, 988, 566, 655, 1222]
// obtener la media
// quito el primero
rentas.unshift(2599)
rentas.push(599)
let suma = 0;
for (let i=0; i<rentas.length; i++){
    suma = suma + rentas[i];
}
console.log(rentas)
console.log(`La media de rentas es: ${suma/rentas.length}`)
*/
/*Crea un sistema de tareas que permita:
•Añadir nuevas tareas
•Mostrar todas las tareas
•Marcar tareas como completadas
•Contar tareas pendientes*/
/*
const tareas = new Array("diseñar", "implementar", "compilar")
console.log(tareas)
// NO PRODUCE ERROR, SE RESPETA LA DIRECCIÓN DE LA REFERENCIA
// AL OBJETO CREADO Y SE LE PUEDE MODIFICAR.
tareas.unshift("reunir información") 
console.log(tareas)
// PRODUCE ERROR POR INTENTO DE REASIGNACIÓN DE LA REFERENCIA,
// Y ESO ESTÁ PROHIBIDO EN JS. const PROHIBE REASIGNAR LA REFERENCIA
// PERO NO PROHIBE MODIFICAR SUS VALORES
//tareas = new Array("otra tarea", "tarea tardes")
tareas.unshift("encender equipo")
tareas.push("apagar equipo")
console.log(tareas)

// SI hemos completado las tareas a lo largo del día, excepto 
// la última interesa marcarlo en el array
// declaro y asigno un array nuevo que tiene las tareas con 
// su estado:
tareasEstado = [];
console.log(typeof tareasEstado )
tareas.forEach(function(cadaTarea, i){
    console.log("número de iteración: " + i)
    // las pares "completas" y las impares "pendientes"
    if (tareas.indexOf(cadaTarea)%2===1){ 
        estatus = "pendiente"
    }
    else{
        estatus = "completa"
    }
    tareasEstado.push(cadaTarea)
    tareasEstado.push(i)
    tareasEstado.push(estatus)
})
console.log(tareasEstado);
*/
/*
Tienes una lista de nombres y edades de los miembros de una familia. 
Este script debe devolver el nombre y la edad del de menor edad de la familia, 
y también lo análogo para el de mayor edad. Ejemplo:
["Ana, 43, "Luis", 45, "Ricardo", 16, "María", 11]-->
la info ["María" , 11]-->menor
la info ["Luis", 45]-->mayor
*/

// esta función "da" el mínimo y el índice para ese mínimo
function minimoFunc(arrayElementos){
    let minimo = arrayElementos[0]
    for (let i=0; i<arrayElementos.length; i++){
        if (minimo>arrayElementos[i]){
            minimo = arrayElementos[i]
            indice = i
        }
    }
    return [minimo, indice]
}
let misNumeros = [-4,0,3,-32, 8, 9, 243, 12]
let elValorMinimoYSuIndice = minimoFunc(misNumeros);
console.log("El mínimo es: " + elValorMinimoYSuIndice[0])
console.log("En el índice: " + elValorMinimoYSuIndice[1])

const familia = ["Ana", 43, "Luis", 45, "Ricardo", 16, "María", 11];
// separo en 2 arrays la información:
const nombres = new Array();
const edades = new Array()
for (let i=0, j=0; i<familia.length; i++){
    if (i%2==1){
        edades[j] = familia[i];
        j++
    }
}
console.log(`Edades: ${edades}`)
for (let i=0, j=0; i<familia.length; i++){
    if (i%2==0){
        nombres[j] = familia[i];
        j++
    }
}
console.log(`Nombres: ${nombres}`)

let maxEdad = edades[0]
let iMax = 0
for (let i=0; i<edades.length; i++){
    if (maxEdad<edades[i]){
        maxEdad = edades[i]
        iMax = i
    }
}
const elMayorArray = [nombres[iMax],edades[iMax]]
console.log(elMayorArray)

// minimoFunc(edades) da dos valores en array, el segundo de ellos es un índice
// el primero es el valor en ese índice para edades
// por otro lado nombres es accedido en el índice correspondiente al segundo de los 
// valores de minimoFunc(edades)

let indiceMinimo = minimoFunc(edades)[1]; // el [1] indica la segunda posición devuelta por minimoFunc
let personaNombreMin = nombres[indiceMinimo];
let edadMinimoPersona = minimoFunc(edades)[0];
const elMenorArray =  [personaNombreMin, edadMinimoPersona]
console.log(elMenorArray)

// crear como funciones la del máximo y el mínimo






function maximo(arrayElementos){
    let maximo = arrayElementos[0]
    for (let i=0; i<arrayElementos.length; i++){
        if (maximo>arrayElementos[i])
            maximo = arrayElementos[i]
    }
}