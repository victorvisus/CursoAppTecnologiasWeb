/*
function saludar(nombre) {
  console.log('¡Hola, ' + nombre + '!')
}

function despedir(nombre) {
  console.log('¡Adiós, ' + nombre + '!')
}

// Función que recibe OTRA FUNCIÓN como parámetro
function procesarUsuario(nombre, accion) {
  accion(nombre) // Ejecutamos la función que nos pasaron
}
// Pasamos diferentes funciones como parámetros
procesarUsuario('Ana', saludar)   // ¡Hola, Ana!
procesarUsuario('Luis', despedir) // ¡Adiós, Luis!
// --- EJEMPLO DE CALCULADORA FLEXIBLE ----

function sumar(a, b) {
  return a + b
}

function multiplicar(a, b) {
  return a * b
}

function restar(a, b) {
  return a - b
}

// Función que recibe una operación como parámetro
function calcular(num1, num2, operacion) {
  const resultado = operacion(num1, num2)
  console.log('El resultado es: ' + resultado)
  return resultado
}

// Usamos diferentes operaciones. En todos los siguientes ejemplos, el responsable
// de invocar a "calcular(..,..,..)" se compromete a pasar 3 argumentos como parámetros:
// número, número, nombre_de_función o bien implementación de función (anónima)
calcular(5, 3, sumar)       // El resultado es: 8
calcular(5, 3, multiplicar) // El resultado es: 15
calcular(5, 3, restar)      // El resultado es: 2

// Función anónima pasada directamente
calcular(10, 2, function(a, b) {
  console.log("Division")
  return a / b
})
// El resultado es: 5
calcular(10, 2, function(a, b) {
  console.log("Potencia")
  return a**b
})
calcular(-9, 7, function(a, b) {
  console.log("Trigonométrica")
  return Math.sin(a) - Math.cos(b)
})*/
// con función flecha: cambia la sintaxis pero mantiene concepto de retorno:
/*
calcular(4, 3, (a, b) => {console.log("potencia"); return a ** b})
function calcular(num1, num2, operacion) {
  const resultado = operacion(num1, num2)
  console.log('El resultado es: ' + resultado)
  return resultado
}*/
function repetirAccion(veces, accion) {
  for (let i = 0; i < veces; i++) {
    accion(i)
  }
}

// Diferentes acciones
repetirAccion(3, function(numero) {
  console.log('Iteración número: ' + numero)
})

repetirAccion(5, function(numero) {
  console.log('⭐'.repeat(numero + 1))
})

repetirAccion(6, function(numero){
  console.log(numero/(numero+1))
})


