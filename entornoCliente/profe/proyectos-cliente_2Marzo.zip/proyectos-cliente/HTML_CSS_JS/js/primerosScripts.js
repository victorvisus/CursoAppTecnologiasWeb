/*console.log("primer código en JS");
let edad = 17
let tieneCarnet = true
const puedeConducir = edad >= 18 && tieneCarnet

/* Para practicar if-else if-else */
/*if (puedeConducir) {
  console.log('Puedes conducir')
} 
else {
  console.log('No puedes conducir')
}
/*determina si un número es par o impar con la función resto*/
/*let numero = 881;
if (numero%2===0)
    console.log("numero PAR")
else
    console.log("numero IMPAR")
*/
/*En este ejercicio debes pedir dos números
 enteros y devolver el cociente 
de dividir el primero entre el segundo, pero si el primer número es menor que 
el segundo no debe hacer la división, sino lanzar un mensaje de error
*/
/*let numero1 = prompt("Escriba un número")
let numero2 = prompt("Escriba otro número")
*/
/*let numero1 = -766; let numero2 = 156;
if (numero1/numero2>0 && numero1/numero2<1){
    console.error("La división da de cociente 0")
}
else {
    console.log(`El resultado de dividir ${numero1} 
    entre ${numero2} es ${numero1/numero2}`)
}

*/
/*                
let dividendo = parseInt(prompt("Primer numero"));
let divisor  = parseInt(prompt("Segundo numero"));
let cociente;
if (divisor != 0){
    cociente = dividendo/divisor;
    alert( dividendo + "/" + divisor + " = " + cociente);
}
else{
   alert("No puedes dividir entre 0");
}*/
/*
En un tramo de un rally los conductores no 
deben ir ni demasiado rápido ni demasiado lentos. 
Este ejercicio debe tomar la longitud del tramo en kilómetros y 
el tiempo empleado, si la velocidad está entre 40 y 60 km/h 
el conductor pasa la prueba en caso contrario es descalificado.
*/
/*let longitudTramo = 1; // en Km
let tiempoTramo = 0.033; // en horas
let descalificado; // booleana
//ejemplo de traza:
console.log(longitudTramo/tiempoTramo);
if (longitudTramo/tiempoTramo<60 && longitudTramo/tiempoTramo>40){
    descalificado = false;
    console.log("Usted no está descalificado")
}
else {
    descalificado = true;
    console.log("Usted está descalificado")
}
//esto no es una traza, sino el resultado final para usuario
console.log(descalificado)
*/
/*let cuenta = 10;
while (cuenta>0){
    cuenta = cuenta -1;
    if (cuenta % 2 ===0) 
        continue
    console.log(cuenta + " segundos");
}
console.log("Take off");
*/

/*tabla de multiplicar del 1 al 10*/
/*
let numero1 = 1; let numero2 = 1;
while (numero1<=10){
    console.log(`LA DEL ${numero1}:`);
    while (numero2<=10){
        console.log(`${numero1} x ${numero2} = ${numero1*numero2}`);
        numero2 = numero2+1;
    }
    numero2 = 1;
    numero1 = numero1+1;
}

  */

let n1 = 1; let n2 = 1;
while (n1<=10){
    console.log(`*****************`);
    console.log(`LA DEL ${n1}: `);
    if (n1%2===1){
        n1 = n1+1; 
        continue; // si es impar por ser n1%2===1, se salta
    }
    while (n2<=10){
        console.log(`${n1} x ${n2} = ${n1*n2}`);
        n2 = n2 +1;
    }
    n2 = 1;// después de esa tabla, el segundo número tiene que ser 1 para la siguiente
    n1 = n1 + 1;
}

/*
const NUMERO_REVISIONES = 3;
let cuentaAtras = 10;
// mientras la cuenta atrás sea mayor que 0
while (cuentaAtras > 0) {
  // mostramos el valor de la cuenta atrás
  console.log(cuentaAtras)
  // creamos una variable para contar las revisiones realizadas
  // y la inicializamos a cero
  let revisionesRealizadas = 0
  // hasta que no hayamos realizado las 3 revisiones...
  while (revisionesRealizadas < NUMERO_REVISIONES) {
    // y sumamos 1 a las revisiones realizadas
    revisionesRealizadas = revisionesRealizadas + 1
    console.log(revisionesRealizadas + ' revisiones realizadas...')
  }
  // ahora podemos restar 1 a la cuenta atrás
  cuentaAtras = cuentaAtras - 1
}
console.log(revisionesRealizadas);*/