/*Hacer una función en JS que sea capaz de reemplazar 
las vocales acentuadas en un texto por vocales sin acentuar.
En primer lugar simplemente probar con una palabra con tildes, 
por ejemplo INFORMACIÓN, y a través de un patrón que se
despliega en un SWITCH permite hacer el intercambio.
*/
let text = "INFÓRMÁCIÓN";
text = text.toLowerCase();
console.log(text)
let pattern = /á/;
//let result = pattern.test(text);
// Buscamos la "á"
let resultado; // esta variable es true si encuentra la "á" en el texto

switch (pattern.test(text)) {
    case true:
        // sustituir la "á". Esto ahora no lo sabemos resolver: implica recorrer letra
        // a letra un texto e ir haciendo reemplazo cuando corresponda    
    }
// el anterior switch debe repetirse para cada letra: en total 5 veces, y además disitinguiendo
// cada letra del texto una a una. QUEDA PENDIENTE DE RESOLUCIÓN.
