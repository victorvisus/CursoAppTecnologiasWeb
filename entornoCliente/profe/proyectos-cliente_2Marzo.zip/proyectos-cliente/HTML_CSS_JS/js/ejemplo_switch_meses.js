const prompt = require('prompt-sync')();// se crea el objeto para lectura estándar
let mes = prompt("Introduzca el nombre de un mes: "); // se captura el mes
let dias;

switch (mes.toLowerCase()) {
    case "enero":
    case "marzo":
    case "mayo":
    case "julio":
    case "agosto":
    case "octubre":
    case "diciembre":
        dias = 31;
        break;
    case "abril":
    case "junio":
    case "septiembre":
    case "noviembre":
        dias = 30;
        break;
    case "febrero":
        dias = 28; // Simplificada (omitimos años bisiestos)
        break;
    default:
        dias = "Mes no válido";
}
console.log(`El mes ${mes.toLowerCase()} tiene ${dias} días`);