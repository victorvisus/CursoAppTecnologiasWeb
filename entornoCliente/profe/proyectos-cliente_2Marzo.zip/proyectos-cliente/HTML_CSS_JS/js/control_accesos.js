//let edad = prompt("Introduzca Edad:");

let edad;  // aquí edad es undefined
const prompt = require('prompt-sync')();// se crea el objeto para lectura estándar
edad = prompt("Introduzca su edad: ");// se pide y captura la edad
console.log(edad);
edad = parseInt(edad); //forzamos a que sea un número entero

if (!isNaN(edad)) { // en el caso de que sea un Número:
    if (edad < 13) {
        console.log("¡Acceso Denegado!")
    }
    else if (edad <= 17 && edad >= 13) {
        console.log("Acceso a contenido para adolescentes")
    }
    else {
        console.log("Acceso completo");
        if (edad > 65) {
            console.log("Descuento senior")
        }
    }
} // en el caso de que NO se un número, es decir, es NaN:
else{
    console.log("Tenía que haber introducido una edad válida")
}