/*let nombre = 'Ana' // Variable global

function saludar() {
    let apellido = 'García' // Variable local
    console.log(nombre + ' ' + apellido) // Puede acceder a ambas
}
*/
//saludar() // "Ana García"
//console.log(nombre) // "Ana" ✅
//console.log(apellido) // ❌ Error: apellido is not defined

/*let global = 'Soy global'
function externa() {
    let externa_var = 'Soy de la función externa'
    function interna() {
        let interna_var = 'Soy de la función interna'
        // Puede acceder a todas:
        console.log(interna_var)  // "Soy de la función interna"
        console.log(externa_var)  // "Soy de la función externa"  
        console.log(global)       // "Soy global"
    }
    // Aquí sólo puedes acceder a "externa_var" y "global"
    console.log("antes de llamar")
    interna()
    // console.log(interna_var) // ❌ Error: no puede acceder
}

// Aquí sólo puedes acceder a la variable "global"
externa()
*/
let nombre = 'Global'

function external1() {
    let nombre = 'External'

    function internal1() {
        let nombre = 'Internal'
        console.log(nombre) // "Internal" - prioridad local
    }

    internal1()
    console.log(nombre) // "External" - prioridad local
}

external1()
console.log(nombre) // "Global" - scope global