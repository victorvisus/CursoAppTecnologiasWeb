function cuentaAtras(numero) {
    // Condición base: Si el número que recibe es
    // menor de 0 entonces salimos de la función
    if (numero < 0) {
        return
    }
    // Si el número era mayor o igual a 0, lo mostramos
    console.log(numero)

    // Y llamamos a la función con el número anterior
    cuentaAtras(numero - 1)
}
cuentaAtras(10)
function factorial(n) {
    // Condición base: Si el número es 0 o 1, devolvemos 1
    // y no llamamos a la función de nuevo
    if (n === 0 || n === 1) {
        return 1
    } else {
        console.log(n)
        // Si el número es mayor que 1, llamamos a la función
        return n * factorial(n - 1)
    }
}

console.log(factorial(5)) // Resultado: 120
console.log(factorial(3)) // Resultado: 6
// función suma recursiva: sumar todos los enteros entre 1 y un número dado n
function sumarRecursivo(n) {
    if (n === 0) {
        return 0
    }
    return n + sumarRecursivo(n - 1)
}
console.log(sumarRecursivo(100));
function fibonacci(n) {
    let secuencia = [0, 1]; // Inicia con los dos primeros números
    //0 1 1 2 3 5 8 13 21 34 55 etc
    if (n <= 0) return [0];
    for (let i = 2; i < n; i++) {
        // Suma los dos anteriores para obtener el siguiente
        secuencia[i] = secuencia[i - 1] + secuencia[i - 2];
    }
    return secuencia;
}

console.log(fibonacci(100)); // Genera los primeros 10 números: [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]