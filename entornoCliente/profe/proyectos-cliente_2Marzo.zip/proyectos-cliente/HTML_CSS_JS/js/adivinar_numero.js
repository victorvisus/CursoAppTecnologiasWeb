const numeroSecreto = 7;
let intentos = 0;
let adivinado = false;
const prompt = require('prompt-sync')();
//edad = prompt("Introduzca su edad: ");
while (!adivinado) {
    let intento = parseInt(prompt("Adivina el número (1-10):"));
    intentos++;
    if (intento === numeroSecreto) {
        console.log(`¡Correcto! Lo has adivinado en ${intentos} intentos.`);
        adivinado = true; // Termina el bucle
    } else {
        console.log("Incorrecto. Inténtalo de nuevo.");

    }
}