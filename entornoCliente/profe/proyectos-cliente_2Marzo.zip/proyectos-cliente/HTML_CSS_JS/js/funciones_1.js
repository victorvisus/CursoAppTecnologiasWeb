// función para devolver un número aleatorio entero entre 1 y 10
function getRandomNumber(){
    const semilla = Math.random(); // está entre 0 y 1 (0,1)
    const amplificada = semilla*10; // está entre 0 y 10 (no llega a 10)
    const truncada = Math.floor(amplificada); // está entre 0 y 9
    const resultado = truncada + 1;
    return resultado;
}

// A continuación el cuerpo principal del programa
// const prompt = require('prompt-sync')(); // innecesario por ausencia de interacción
let miNumeroAleatorio = getRandomNumber();
for (let i=1; i<=100; i++){
    miNumeroAleatorio = getRandomNumber();
    console.log(miNumeroAleatorio);
}