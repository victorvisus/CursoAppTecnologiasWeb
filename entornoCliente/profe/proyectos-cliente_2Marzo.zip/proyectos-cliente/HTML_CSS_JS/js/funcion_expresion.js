/*console.log("suma expresión-función: " + suma(8,9))
console.log("suma expresión-función: " + suma(81,99))
console.log("suma expresión-función: " + suma(18,39))
// esto es una function expression: Declarada tras la invocación
// da error, pq al ser función-expresión no hace HOISTING
const suma = function (a, b) {
  return a + b
}*/

let suma1 = sumFuncion(8,9)
console.log("suma ordinaria: " + suma1)
suma1 = sumFuncion(81,99)
console.log("suma ordinaria: " + suma1)
suma1 = sumFuncion(18,39)
console.log("suma ordinaria: " + suma1)
// esto es una declaración de función ordinaria:
//  HOISTING es válido
function sumFuncion(a, b) {
  return a + b
}
// FUNCIONES FLECHA:
const saludar = (nombre) => { // recordar que saludar es función-expresión
  console.log('Hola ' + nombre)
}
saludar("Ramiro")

const operar = (a,b) => a+b
console.log(operar(4,3))