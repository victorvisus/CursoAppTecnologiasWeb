/**
 * Exporta clase GestorProducto
Propiedad: array de productos
Método: agregar(producto) - valida antes de agregar
Método: listar() - devuelve strings formateados
Método: obtenerTotal() - suma de precio * stock de todos
 * 
 */

import {validarPrecio, validarStock} from "../utils/validaciones.js"
//import * as Formateadores from `../utils/formateo.js` 
import {formatearPrecio, formatearStock} from "../utils/formateo.js"

export default class GestorProducto{
    constructor(arrayProductos){
        this.productos = arrayProductos
    }
    agregar(productoNuevo){
        if (validarPrecio(productoNuevo.precio) && validarStock(productoNuevo.stock))
            this.productos.push(productoNuevo)
    }
    listar(){ //tiene que devolver strings formateados
        let listado = ""
        this.productos.forEach(p => { listado = listado + `Precio: ${formatearPrecio(p)}, Stock: ${formatearStock(p)} \n`})
        return listado
    }
    obtenerTotal(){
        let suma = 0
        this.productos.forEach(p => {
            if (validarPrecio(p) && validarStock(p)){ suma = p.precio*p.stock }
        })
        return suma
    }
}