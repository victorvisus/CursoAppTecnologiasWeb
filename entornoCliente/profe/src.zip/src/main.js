/**
 * Src/utils/formateo.js
 * Importa todo lo necesario
 * Crea algunos productos 
 * Agrégalos al gestor
 * Muestra la lista y el total
 */
import GestorProducto from "./gestor/GestorProducto.js";
import Producto from "./modelos/Producto.js";
const fruteria = [
  new Producto("Melón", 2.5054, 15),
  new Producto("Sandía", 4.0233, 10),
  new Producto("Plátano", 1.3320, 40),
  new Producto("Manzana", 1.80, 50),
  new Producto("Pera", 1.60, 30),
  new Producto("Naranja", 1.10, 60),
  new Producto("Fresa", 3.50, 20),
  new Producto("Uva", 2.80, 25),
  new Producto("Kiwi", 3.20, 18),
  new Producto("Piña", 2.90, 12),
  new Producto("Mango", 2.30, 15),
  new Producto("Cereza", 5.00, 10),
  new Producto("Limón", 0.90, 100),
  new Producto("Aguacate", 4.50, 14)
];
const gestorFruteria = new GestorProducto(fruteria)
gestorFruteria.agregar(new Producto("Cereza Premium", 9.00, 4))
gestorFruteria.agregar(new Producto("Lima", 3.90, 6))
gestorFruteria.agregar(new Producto("Lichi", 6.50, 2))
console.log(gestorFruteria.listar())
console.log(gestorFruteria.obtenerTotal())
