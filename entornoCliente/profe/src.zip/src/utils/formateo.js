/*Export función formatearPrecio(precio) - devuelve "XX,00€"
Export función formatearStock(stock) - devuelve "X unidades"*/

function formatearPrecio(precio){
    return String(Math.round(precio*100)/100).concat("€").replace(".",",")
}
//console.log(formatearPrecio(345.3456))
function formatearStock(stock){
    return `${stock} unidades`
}

export {formatearPrecio,formatearStock}