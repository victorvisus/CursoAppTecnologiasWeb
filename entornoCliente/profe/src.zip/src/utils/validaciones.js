
function validarPrecio(precio){
    return precio>0?true:false}
function validarStock(stock){
    return stock>=0?true:false}

export {validarPrecio, validarStock}