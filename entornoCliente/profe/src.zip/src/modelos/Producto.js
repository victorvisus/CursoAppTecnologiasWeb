/*
Constructor: nombre, precio, stock
Métodos: toString(), estaDisponible()
Src / utils / validaciones.js
Export función validarPrecio(precio) - debe ser > 0
Export función validarStock(stock) - debe ser => 0
*/
export default class Producto{
    constructor(nombre, precio, stock){
        this.nombre = nombre
        this.precio = precio
        this.stock = stock
    }
    toString(){
        return `Nombre: ${this.nombre} -Precio: ${this.precio} -Stock: ${this.stock} -`
    }
    estaDiponible(){
        if (this.stock>0)
            return true
    }
}