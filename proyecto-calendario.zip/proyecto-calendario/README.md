# TechCalendar - Sistema de Gestión de Citas

TechCalendar es una aplicación web ligera diseñada para la gestión de reservas técnicas. Permite a los usuarios agendar citas de manera eficiente, validando la disponibilidad tanto por reservas previas como por la hora actual del sistema.

## 📁 Estructura del Proyecto

El proyecto sigue una arquitectura de separación de intereses (Separation of Concerns):

```text
proyecto-calendario/
├── calendario_citas.html  # Estructura principal y marcado semántico
├── css/
│   └── style_citas.css    # Estilos personalizados y ajustes de UI
├── js/
│   └── app_citas.js       # Lógica de negocio y configuración de Tailwind
└── README.md              # Documentación del proyecto
```

## 🛠️ Tecnologías Utilizadas

- **HTML5**: Estructura semántica.
- **Tailwind CSS**: Framework de utilidades CSS para un diseño moderno y responsivo.
- **JavaScript (Vanilla)**: Lógica de la aplicación y manipulación del DOM.
- **Google Fonts (Inter & Source Sans 3)**: Tipografía personalizada.
- **LocalStorage**: Persistencia de datos en el navegador.

## 🚀 Características Principales

1.  **Agendamiento Dinámico**: Formulario intuitivo con validación de campos obligatorios.
2.  **Validación de Disponibilidad**:
    - **Cruce de Citas**: El sistema impide reservar un hueco que ya ha sido guardado previamente.
    - **Control de Horario Real**: Si se selecciona el día de hoy, las horas que ya han pasado se deshabilitan automáticamente.
3.  **Persistencia de Datos**: Las citas se guardan en el `localStorage` del navegador, permitiendo que la información se mantenga al recargar la página.
4.  **Interfaz Moderna**: Diseño oscuro (Dark Mode) con estética premium, efectos de desenfoque (backdrop-blur) y animaciones suaves en modales.
5.  **Feedback Visual**: Modales de confirmación para citas exitosas y alertas para errores de disponibilidad.

## 📖 Instrucciones de Uso

1.  Abre `calendario_citas.html` en cualquier navegador web moderno.
2.  Introduce tus datos personales (Nombre, Teléfono, Email).
3.  Selecciona una fecha (mínimo hoy).
4.  Elige una de las franjas horarias disponibles. Notarás que algunas opciones pueden estar bloqueadas si ya no están disponibles.
5.  Haz clic en **"Agendar Cita"**.
6.  Recibirás una confirmación visual instantánea.

## 🔧 Configuración Técnica

- **Rango Horario**: Configurado de 09:00 a 19:00 (con pausa de 14:00 a 15:00).
- **Configuración Tailwind**: Se encuentra en `js/app_citas.js` bajo el objeto `tailwind.config`, permitiendo una fácil personalización de colores y fuentes.
