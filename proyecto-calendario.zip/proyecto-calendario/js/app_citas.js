// --- Configuración de Tailwind ---
tailwind.config = {
  theme: {
    extend: {
      colors: {
        "bg-main": "#0E0E11",
        "card-bg": "#1C1E22",
        "border-base": "#3A3D42",
        "text-sec": "#B5B8BE",
        accent: "#3AFF7A",
        "text-main": "#F2F3F5",
      },
      fontFamily: {
        sans: ['"Source Sans 3"', "sans-serif"],
        title: ["Inter", "sans-serif"],
      },
    },
  },
};

// --- Lógica del Calendario ---

// Inicializar almacenamiento
let citasRegistradas =
  JSON.parse(localStorage.getItem("citasRegistradas")) || [];

const form = document.getElementById("appointmentForm");
const modalOverlay = document.getElementById("modalOverlay");
const modalContent = document.getElementById("modalContent");
const modalTitle = document.getElementById("modalTitle");
const modalBody = document.getElementById("modalBody");
const dateInput = document.getElementById("date");

// Función para validar disponibilidad
function checkAvailability(fecha, hora) {
  return !citasRegistradas.some(
    (cita) => cita.fecha === fecha && cita.hora === hora,
  );
}

// Función para mostrar modal
function showModal(type, data = null) {
  modalOverlay.classList.remove("hidden");
  modalOverlay.classList.add("flex");

  // Animación de entrada
  setTimeout(() => {
    modalContent.classList.remove("scale-95", "opacity-0");
    modalContent.classList.add("scale-100", "opacity-100");
  }, 10);

  if (type === "success") {
    modalTitle.innerText = "¡Cita Confirmada!";
    modalTitle.classList.add("text-accent");
    modalTitle.classList.remove("text-red-500");

    modalBody.innerHTML = `
                    <div class="space-y-2">
                        <p><strong class="text-text-main">Nombre:</strong> ${data.nombre}</p>
                        <p><strong class="text-text-main">Fecha:</strong> ${data.fecha}</p>
                        <p><strong class="text-text-main">Hora:</strong> ${data.hora}</p>
                        <p><strong class="text-text-main">Email:</strong> ${data.email}</p>
                        <p><strong class="text-text-main">Teléfono:</strong> ${data.tel}</p>
                        <div class="mt-4 p-3 bg-bg-main rounded border border-border-base italic text-xs">
                            ${data.comentarios || "Sin comentarios adicionales."}
                        </div>
                    </div>
                `;
  } else {
    modalTitle.innerText = "Horario no disponible";
    modalTitle.classList.add("text-red-500");
    modalTitle.classList.remove("text-accent");

    modalBody.innerHTML = `
                    <p>Lo sentimos, ya existe una cita programada para el <strong class="text-text-main">${data.fecha}</strong> a las <strong class="text-text-main">${data.hora}</strong>.</p>
                    <p class="mt-2">Por favor, selecciona otro horario o día diferente.</p>
                `;
  }
}

// Función para cerrar modal
function closeModal() {
  modalContent.classList.remove("scale-100", "opacity-100");
  modalContent.classList.add("scale-95", "opacity-0");

  setTimeout(() => {
    modalOverlay.classList.add("hidden");
    modalOverlay.classList.remove("flex");
  }, 200);
}

// Función para actualizar horas disponibles
function updateAvailableHours() {
  const selectedDate = dateInput.value;
  const timeSelect = document.getElementById("time");
  const options = timeSelect.querySelectorAll("option");

  if (!selectedDate) return;

  // Obtener fecha y hora actual
  const now = new Date();
  const today = now.toISOString().split("T")[0];
  const currentHour = now.getHours();
  const currentMinutes = now.getMinutes();

  options.forEach((option) => {
    if (option.value === "") return; // Ignorar el placeholder

    const isOccupied = !checkAvailability(selectedDate, option.value);

    // Nueva lógica: Verificar si la hora ya pasó (solo si es hoy)
    let isPast = false;
    if (selectedDate === today) {
      const [optionHour, optionMinutes] = option.value.split(":").map(Number);
      if (
        optionHour < currentHour ||
        (optionHour === currentHour && optionMinutes <= currentMinutes)
      ) {
        isPast = true;
      }
    }

    if (isOccupied || isPast) {
      option.disabled = true;
      option.classList.add("text-gray-600");
    } else {
      option.disabled = false;
      option.classList.remove("text-gray-600");
    }
  });

  // Si la hora seleccionada actualmente ya no está disponible, resetear el select
  const currentSelected = timeSelect.value;
  if (currentSelected) {
    const isOccupied = !checkAvailability(selectedDate, currentSelected);
    let isPast = false;
    if (selectedDate === today) {
      const [selHour, selMin] = currentSelected.split(":").map(Number);
      if (
        selHour < currentHour ||
        (selHour === currentHour && selMin <= currentMinutes)
      ) {
        isPast = true;
      }
    }

    if (isOccupied || isPast) {
      timeSelect.value = "";
    }
  }
}

// Manejo del formulario
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const cita = {
      nombre: document.getElementById("fullName").value,
      tel: document.getElementById("phone").value,
      email: document.getElementById("email").value,
      fecha: document.getElementById("date").value,
      hora: document.getElementById("time").value,
      comentarios: document.getElementById("comments").value,
    };

    if (checkAvailability(cita.fecha, cita.hora)) {
      // Guardar cita
      citasRegistradas.push(cita);
      localStorage.setItem(
        "citasRegistradas",
        JSON.stringify(citasRegistradas),
      );

      // Mostrar éxito
      showModal("success", cita);

      // Resetear form y actualizar disponibilidad
      form.reset();
      updateAvailableHours();
    } else {
      // Mostrar error
      showModal("error", { fecha: cita.fecha, hora: cita.hora });
      updateAvailableHours(); // Por si acaso cambió algo
    }
  });
}

// Configurar fecha mínima (hoy) y listeners
if (dateInput) {
  const today = new Date().toISOString().split("T")[0];
  dateInput.setAttribute("min", today);
  dateInput.addEventListener("change", updateAvailableHours);
}

// Global scope for closeModal if needed by inline button
window.closeModal = closeModal;
